# PO Control Center – web app with its own login

Anyone you create an account for can sign in at your site's URL. No Claude account needed.

## Run locally
    ADMIN_USER=admin ADMIN_PASSWORD='choose-a-strong-one' node server.js
    # open http://localhost:3000

If you skip ADMIN_PASSWORD, the first admin is `admin` / `Admin@2026`. Change it after signing in.

## Put it on the web (pick one)
Any host that runs Node 18+ works. No `npm install` needed (zero dependencies).

**Render / Railway / Fly.io (easiest):**
1. Push this folder to a GitHub repo, create a new "Web Service" from it.
2. Start command: `node server.js`
3. Set env vars: `ADMIN_USER`, `ADMIN_PASSWORD`, `DATA_DIR=/data`
4. **Attach a persistent disk mounted at `/data`** (otherwise users and published data are lost on redeploy).
5. Use the HTTPS URL the host gives you.

**Your own VPS:** `node server.js` behind nginx/Caddy with HTTPS (session cookies are marked Secure when the proxy sends `X-Forwarded-Proto: https`); keep it alive with systemd or pm2.

## Using it
- Admin: **Users** page -> create user (username, password, Viewer or Admin), reset passwords, delete users.
- Viewer: dashboard, PO tracker, job comparison. Read-only.
- Admin: **Data** page -> upload an updated Excel, or publish. Every user sees the new data on next load.

## Security notes
- Passwords are stored as salted scrypt hashes; sessions are signed HttpOnly cookies (12 h); login is rate-limited.
- PO data is only sent to signed-in users (it is not in the page source).
- ALWAYS serve over HTTPS. Back up the `DATA_DIR` folder (users.json, data.json).
- No password-recovery email: an admin resets passwords.
