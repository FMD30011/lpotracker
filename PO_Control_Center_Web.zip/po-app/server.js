// PO Control Center - standalone server. Zero dependencies (Node 18+).
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const PORT = process.env.PORT || 3000;
const DIR = process.env.DATA_DIR || path.join(__dirname, 'storage');
fs.mkdirSync(DIR, { recursive: true });
const F = { users: path.join(DIR, 'users.json'), data: path.join(DIR, 'data.json'), secret: path.join(DIR, 'secret.key'), log: path.join(DIR, 'activity.json') };
const readJ = (f, d) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } };
const writeJ = (f, v) => { fs.writeFileSync(f + '.tmp', JSON.stringify(v)); fs.renameSync(f + '.tmp', f); };

if (!fs.existsSync(F.data)) fs.copyFileSync(path.join(__dirname, 'seed-data.json'), F.data);
const SECRET = process.env.SESSION_SECRET || (fs.existsSync(F.secret) ? fs.readFileSync(F.secret, 'utf8') : (() => { const s = crypto.randomBytes(32).toString('hex'); fs.writeFileSync(F.secret, s); return s; })());

const hash = (pw, salt = crypto.randomBytes(16).toString('hex')) => ({ salt, hash: crypto.scryptSync(pw, salt, 64).toString('hex') });
const verify = (pw, u) => { const h = crypto.scryptSync(pw, u.salt, 64); const b = Buffer.from(u.hash, 'hex'); return h.length === b.length && crypto.timingSafeEqual(h, b); };
let users = readJ(F.users, null);
if (!users) {
  const pw = process.env.ADMIN_PASSWORD || 'Admin@2026';
  const name = (process.env.ADMIN_USER || 'admin').toLowerCase();
  users = { [name]: { role: 'admin', ...hash(pw), created: Date.now() } };
  writeJ(F.users, users);
  console.log(`\n=== First run: admin user "${name}" created. Password: ${pw}\n=== Change it after first sign-in (Users page).\n`);
}
const save = () => writeJ(F.users, users);
const log = (who, what) => { const l = readJ(F.log, []); l.unshift({ ts: Date.now(), who, what }); writeJ(F.log, l.slice(0, 200)); };

const sign = p => { const b = Buffer.from(JSON.stringify(p)).toString('base64url'); return b + '.' + crypto.createHmac('sha256', SECRET).update(b).digest('base64url'); };
const unsign = t => { if (!t) return null; const [b, s] = t.split('.'); if (!b || !s) return null; const e = crypto.createHmac('sha256', SECRET).update(b).digest('base64url'); if (s.length !== e.length || !crypto.timingSafeEqual(Buffer.from(s), Buffer.from(e))) return null; try { const p = JSON.parse(Buffer.from(b, 'base64url').toString()); return p.exp > Date.now() ? p : null; } catch { return null; } };
const cookie = req => Object.fromEntries((req.headers.cookie || '').split(';').map(c => c.trim().split('=')).filter(x => x[0]).map(([k, ...v]) => [k, v.join('=')]));
const auth = req => { const p = unsign(cookie(req).sid); return p && users[p.u] ? { name: p.u, role: users[p.u].role } : null; };

const attempts = new Map();
const limited = ip => { const a = (attempts.get(ip) || []).filter(t => Date.now() - t < 15 * 60000); attempts.set(ip, a); return a.length >= 10; };

const send = (res, code, body, headers = {}) => { const s = typeof body === 'string' ? body : JSON.stringify(body); res.writeHead(code, { 'Content-Type': typeof body === 'string' ? 'text/html; charset=utf-8' : 'application/json', 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-store', ...headers }); res.end(s); };
const readBody = req => new Promise((ok, no) => { let n = 0; const c = []; req.on('data', d => { n += d.length; if (n > 60e6) { no(Error('Payload too large')); req.destroy(); } else c.push(d); }); req.on('end', () => { try { ok(JSON.parse(Buffer.concat(c).toString() || '{}')); } catch { no(Error('Invalid JSON')); } }); });
const validName = n => /^[a-z0-9._-]{3,32}$/.test(n);

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x'), p = url.pathname, me = auth(req);
  const err = (c, m) => send(res, c, { error: m });
  try {
    if (req.method === 'GET' && (p === '/' || p === '/index.html')) return send(res, 200, fs.readFileSync(path.join(__dirname, 'public', 'index.html'), 'utf8'));
    if (!p.startsWith('/api/')) return err(404, 'Not found');
    if (req.method !== 'GET' && !(req.headers['content-type'] || '').includes('application/json')) return err(415, 'JSON required');

    if (p === '/api/login' && req.method === 'POST') {
      const ip = req.socket.remoteAddress; if (limited(ip)) return err(429, 'Too many attempts. Try again later.');
      const { username = '', password = '' } = await readBody(req); const u = users[String(username).toLowerCase()];
      if (!u || !verify(String(password), u)) { attempts.get(ip).push(Date.now()); return err(401, 'Invalid username or password'); }
      const secure = (req.headers['x-forwarded-proto'] === 'https') ? '; Secure' : '';
      return send(res, 200, { name: username.toLowerCase(), role: u.role }, { 'Set-Cookie': `sid=${sign({ u: username.toLowerCase(), exp: Date.now() + 12 * 3600e3 })}; HttpOnly; SameSite=Lax; Path=/; Max-Age=43200${secure}` });
    }
    if (p === '/api/logout' && req.method === 'POST') return send(res, 200, { ok: 1 }, { 'Set-Cookie': 'sid=; HttpOnly; Path=/; Max-Age=0' });
    if (!me) return err(401, 'Not signed in');
    if (p === '/api/me') return send(res, 200, me);
    if (p === '/api/data' && req.method === 'GET') return send(res, 200, fs.readFileSync(F.data, 'utf8'));
    if (p === '/api/password' && req.method === 'POST') {
      const { current = '', password = '' } = await readBody(req);
      if (!verify(String(current), users[me.name])) return err(400, 'Current password is wrong');
      if (String(password).length < 8) return err(400, 'Password must be at least 8 characters');
      Object.assign(users[me.name], hash(String(password))); save(); return send(res, 200, { ok: 1 });
    }
    if (me.role !== 'admin') return err(403, 'Admin only');
    if (p === '/api/data' && req.method === 'POST') {
      const rows = await readBody(req); if (!Array.isArray(rows) || !rows.length) return err(400, 'Expected a non-empty array of rows');
      writeJ(F.data, rows); log(me.name, `published ${rows.length} rows`); return send(res, 200, { rows: rows.length });
    }
    if (p === '/api/users' && req.method === 'GET') return send(res, 200, { users: Object.entries(users).map(([name, u]) => ({ name, role: u.role, created: u.created })), log: readJ(F.log, []).slice(0, 15) });
    if (p === '/api/users' && req.method === 'POST') {
      const { username = '', password = '', role = 'viewer' } = await readBody(req); const n = String(username).toLowerCase();
      if (!validName(n)) return err(400, 'Username: 3-32 chars, letters/numbers . _ -');
      if (String(password).length < 8) return err(400, 'Password must be at least 8 characters');
      if (users[n]) return err(409, 'User already exists'); if (!['admin', 'viewer'].includes(role)) return err(400, 'Bad role');
      users[n] = { role, ...hash(String(password)), created: Date.now() }; save(); log(me.name, `created user ${n} (${role})`); return send(res, 200, { ok: 1 });
    }
    const m = p.match(/^\/api\/users\/([^/]+)(\/password)?$/);
    if (m) {
      const n = decodeURIComponent(m[1]).toLowerCase(); if (!users[n]) return err(404, 'No such user');
      if (m[2] && req.method === 'POST') { const { password = '' } = await readBody(req); if (String(password).length < 8) return err(400, 'Password must be at least 8 characters'); Object.assign(users[n], hash(String(password))); save(); log(me.name, `reset password for ${n}`); return send(res, 200, { ok: 1 }); }
      if (!m[2] && req.method === 'DELETE') { if (n === me.name) return err(400, "You can't delete yourself"); delete users[n]; save(); log(me.name, `deleted user ${n}`); return send(res, 200, { ok: 1 }); }
    }
    return err(404, 'Not found');
  } catch (e) { return err(400, e.message); }
}).listen(PORT, () => console.log('PO Control Center on port ' + PORT));
